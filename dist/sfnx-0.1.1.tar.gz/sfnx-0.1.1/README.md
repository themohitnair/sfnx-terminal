# sfnx-terminal
A minimal terminal password manager that uses Typer, SQLModel, Argon2 Key Derivation, AES and SQLite

# Installation
## Archlinux Install: 
```sudo pacman -S pipx```
```pipx install sfnx```

# Documentation:
Coming soon...

# Usage Instructions:
Coming soon...

