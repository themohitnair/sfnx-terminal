# sfnx-terminal
A minimal terminal password manager that uses Typer, SQLModel, Argon2 Key Derivation, AES and SQLite
